import java.util.Scanner;
public class Problem3 {
        static Scanner scan = new Scanner(System.in);
        public static <E extends Comparable<E>> int binarySearch(E[] list, E key) {
            sort(list);
            int low = 0;
            int high = list.length - 1;

            while (high >= low) {
                int mid = (low + high) / 2;
                if (key.compareTo(list[mid]) < 0)
                    high = mid - 1;
                else if (key.compareTo(list[mid]) == 0)
                    return mid;
                else
                    low = mid + 1;
            }

            return -low - 1; // Now high < low

        }

        public static <E extends Comparable<E>> void sort(E[] list) {
            java.util.Arrays.sort(list);
        }


        public static void main(String[] args) {

            // Create an array of a hundred random integers in the range of 0 to 99, inclusive.
            Integer[] randomIntegers = getRandomArray();

            // Display the contents of the array.
            System.out.println("Displaying 100 Random Integers : ");
            displayArray(randomIntegers);

            // Prompt the user to enter an integer.
            System.out.print("Enter an Integer to search an element : ");
            int searchInteger = scan.nextInt();

            // Use binarySearch() to check if the integer is in the array.
            int searchIndex = binarySearch(randomIntegers, searchInteger);

            // Printing search result
            printSearchResult(randomIntegers, searchInteger, searchIndex);

            // -------------------------------------------------------------------------------------------

            // Create an array of random strings, 1 to 10 characters in length.
            String[] randomStrings = getRandomStringArray();

            // Display the strings.
            System.out.println("Displaying 5 Random Strings : ");
            displayArray(randomStrings);

            // Prompt the user to enter a string.
            System.out.print("Enter a string to search in array : ");
            String searchName = scan.next();

            // Use binarySearch() to check if the string is in the array.
            searchIndex = binarySearch(randomStrings, searchName);

            // Print search result
            printSearchResult(randomStrings, searchName, searchIndex);

            // -------------------------------------------------------------------------------------------

            // Create an array of random Employee objects (use random strings for the first name and last name and random numbers for the salary).
            Employee[] randomEmployees = getRandomEmployees();

            // Display the contents of the array.
            System.out.println("Displaying 5 Random Employees : ");
            displayArray(randomEmployees);

            // Prompt the user to enter the first name and last name to search the array with binarySearch().
            System.out.print("Enter first name to search : ");
            String firstNameSearchStr = scan.next();

            System.out.print("Enter last name to search : ");
            String lastNameSearchStr = scan.next();

            Employee searchEmployee = new Employee(firstNameSearchStr, lastNameSearchStr);

            // Display the result of the search.
            searchIndex = binarySearch(randomEmployees, searchEmployee);

            printSearchResult(randomEmployees, searchEmployee, searchIndex);
        }

        private static Employee[] getRandomEmployees() {
            Employee[] employees = new Employee[5];
            double minSalary = 1000.0;
            double maxSalary = 100_000.0;

            for (int i = 0; i < employees.length; i++) {
                String firstName = getRandomNameofLength(5);
                String lastName = getRandomNameofLength(5);
                double salary = Math.round((Math.random() * (maxSalary - minSalary + 1) + minSalary) * 100.0) / 100.0;
                employees[i] = new Employee(firstName, lastName, salary);
            }

            return employees;
        }

        private static String[] getRandomStringArray() {
            String[] names = new String[5];
            for (int i = 0; i < names.length; i++) {
                int randomStringLength = (int) (1 + Math.random() * 10);
                names[i] = getRandomNameofLength(randomStringLength);
            }

            return names;
        }

        private static String getRandomNameofLength(int randomStringLength) {
            String name = "";
            for (int i = 0; i < randomStringLength; i++) {
                name += (char) ('a' + Math.random() * 26);
            }

            return name;
        }

        private static <E> void printSearchResult(E[] list, E searchInteger, int searchIndex) {
            if (searchIndex < 0) {
                System.out.println(" ==> Element " + searchInteger + " is not found in the array");
            } else {
                System.out.println(" ==> Element " + list[searchIndex] + " is found in the array");
            }
            System.out.println();
        }

        private static Integer[] getRandomArray() {
            Integer[] input = new Integer[100];
            for (int i = 0; i < 100; i++) {
                int randomNumber = (int) (Math.random() * 100);
                input[i] = randomNumber;
            }

            return input;
        }

        private static void displayArray(Object[] list) {
            for (Object item : list) {
                System.out.print(item + " ");
            }
            System.out.println();
            System.out.println();
        }

}


import java.util.ArrayList;

public class Problem1 {
        public static void main(String[] args) {
            ArrayList<Integer> intInput = getRandomList(new Integer(0), 0, 100);
            System.out.println("\n100 random numbers in range 0 and 9 : ");
            displayArray(intInput);
            ArrayList<Integer> intResult = removeDuplicates(intInput);
            System.out.println("Result after removing duplicates : ");
            displayArray(intResult);
            ArrayList<Character> charInput = getRandomList(new Character('a'), 97, 122);
            System.out.println("\n100 random lowercase characters ");
            displayArray(charInput);
            ArrayList<Character> charResult = removeDuplicates(charInput);
            System.out.println("Result after removing duplicates characters: ");
            displayArray(charResult);

        }
        private static <E> ArrayList<E> getRandomList(E type, int min, int max) {
            ArrayList<E> input = new ArrayList<>();
            for (int i = 0; i < 100; i++) {
                if (type instanceof Integer) {
                    int randomNumber = (int) (Math.random() * (max - min + 1)) + min;
                    Integer ran = new Integer(randomNumber);
                    input.add((E) ran);
                } else if (type instanceof Character) {
                    char randomChar = (char) ((int) (Math.random() * (max - min + 1)) + min);
                    Character ran = new Character(randomChar);
                    input.add((E) ran);
                }
            }

            return input;
        }

        public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list) {
            ArrayList<E> result = new ArrayList<>();

            for (E ele : list) {
                if (!result.contains(ele))
                    result.add(ele);
            }
            return result;
        }

        private static <E> void displayArray(ArrayList<E> list) {
            for (E item : list) {
                System.out.print(item + " ");
            }
            System.out.println('\n');
        }

    }

import java.lang.reflect.Array;
import java.util.ArrayList;
public class Problem2 {
        public static void main(String[] args) {

            Integer[] intInput = getRandomList(new Integer(0), 0, 10001);
            System.out.println("\n100 random numbers in range 0 and 10000 : ");
            displayArray(intInput);
            int result = max(intInput);
            System.out.println("Max value : " + result);
            Double[] doubleInput = getRandomList(new Double(0), 0, 1);
            System.out.println("\n100 random double numbers in range 0.0 and 1.0(Exclusive) : ");
            displayArray(doubleInput);
            double result1 = max(doubleInput);
            System.out.println("Max value : " + result1);

        }
        private static <E> E[] getRandomList(E type, int min, int max) {
            E[] input = (E[]) Array.newInstance(type.getClass(), 100);
            for (int i = 0; i < 100; i++) {
                if (type instanceof Integer) {
                    int randomNumber = (int) (Math.random() * (max - min + 1)) + min;
                    Integer ran = new Integer(randomNumber);
                    input[i] = ((E) ran);
                } else if (type instanceof Double) {
                    double randomChar = Math.random();
                    Double ran = new Double(randomChar);
                    input[i] = ((E) ran);
                }
            }

            return input;
        }

        public static <E extends Comparable<E>> E max(E[] list) {

            E max = list[0];
            for (int i = 0; i < list.length; i++) {
                if (max.compareTo(list[i]) < 0)
                    max = list[i];
            }

            return max;
        }

        private static void displayArray(Object[] list) {
            for (Object item : list) {
                System.out.print(item + " ");
            }
            System.out.println('\n');
        }

}


public class Employee implements Comparable<Employee>{

    private String firstName;
    private String lastName;
    private double salary;

    public Employee(String firstName, String lastName, double salary) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.salary = salary;
    }

    public Employee(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.salary = 0;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", salary=" + salary +
                "}\n";
    }

    @Override
    public int compareTo(Employee e) {
        if(firstName.compareTo(e.getFirstName()) == 0)
            return lastName.compareTo((e.getLastName()));
        else
            return firstName.compareTo(e.getFirstName());
    }
}

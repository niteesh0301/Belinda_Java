import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class Problem4 {

        private ArrayList<Double> objects;
        private double maxWeight;
        private double totalWeight;

        public  Problem4() {

        }

        public Problem4(double maxWeight) {
            this.maxWeight = maxWeight;
            totalWeight = 0;
            objects = new ArrayList<>();
        }

        public boolean addItem(double weight) {
            if ((totalWeight + weight) <= maxWeight) {
                totalWeight += weight;
                objects.add(weight);
                return true;
            }
            return false;
        }

        public int getNumberOfObjects() {
            return objects.size();
        }

        @Override
        public String toString() {
            return "Bin{" +
                    "objects=" + objects +
                    ", maxWeight=" + maxWeight +
                    ", totalWeight=" + totalWeight +
                    '}';
        }

        //    MAIN METHOD
        public static void main(String[] args) {
            Scanner scan = new Scanner(System.in);

            System.out.print("Enter the number of objects: ");
            int totalObjects = scan.nextInt();
            System.out.println();
            ArrayList<Double> objects = new ArrayList<>(totalObjects);

            System.out.print("Enter the weights of the objects: ");
            for (int i = 0; i < totalObjects; i++) {
                double weight = scan.nextDouble();
                objects.add(weight);
            }

            Collections.sort(objects, Collections.reverseOrder());
            ArrayList<Problem4> containers = getMinContainers(objects);

            displayContainers(containers);

        }

        private static void displayContainers(ArrayList<Problem4> containers) {
            int i = 1;
            System.out.println();
            for (Problem4 container : containers) {
                System.out.println("Container " + i + " contains objects with weight " + getObjects(container));
                System.out.println();
                i++;
            }
        }

        private static ArrayList<Problem4> getMinContainers(ArrayList<Double> objects) {
            ArrayList<Problem4> containers = new ArrayList<>();

            while (!objects.isEmpty()) {
                Problem4 currentContainer = new Problem4(10);

                Iterator<Double> iterator = objects.iterator();

                while (iterator.hasNext()) {
                    Double object = iterator.next();
                    if (currentContainer.addItem(object)) {
                        iterator.remove();
                    }
                }

                containers.add(currentContainer);
            }

            return containers;
        }

        private static String getObjects(Problem4 container) {
            String res = "";
            for (Double weight : container.objects) {
                res += weight + " ";
            }

            return res;
        }
}

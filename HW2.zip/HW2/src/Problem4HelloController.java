import javafx.scene.control.Label;

public class Problem4HelloController {
    private Label welcomeText;
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
}

public class Problem2RandomString {
        public static String[] getRandomStringArray(int length) {
            String[] names = new String[length];
            for (int i = 0; i < names.length; i++) {
                int randomStringLength = (int) (5 + Math.random() * (10 - 5 + 1));
                names[i] = getRandomString(randomStringLength);
            }
            return names;
        }


        public static String getRandomString(int randomStringLength) {
            String name = "";
            for (int i = 0; i < randomStringLength; i++) {
                name += (char) ('a' + Math.random() * 26);
            }

            return name;
        }
}

package com.example.hw3;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

//DON'T FORGET TO ADD the mysql jar file to your project. And delete mine.

public class BabyNamesPopulateDB {
    private static PreparedStatement preparedStatement;

    public static void main(String[] args) throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        System.out.println("Driver loaded");

        Connection connection = DriverManager.getConnection(
                "jdbc:mysql://localhost/babynames?serverTimezone=UTC", "root", "nitish@3P");

        String query = "INSERT INTO babyname VALUES(? , ? , ? , ?); ";

        //add the prepared statement that will insert tuple into babyname
        preparedStatement = connection.prepareStatement(query);

        //declare variables
        int boyNum, girlNum;
        String boyName, girlName;
        Scanner data;

        //loop to read files
        for (int year = 2001; year <= 2010; year++) {
            //go here to see how a single year of date is formatted
            //http://liveexample.pearsoncmg.com/data/babynamesranking2001.txt
            //there is a separate textfile for each year, 2001 thru 2010
            data = new Scanner(new URL(
                    "http://liveexample.pearsoncmg.com/data/babynamesranking" + year + ".txt").openStream());
            System.out.print(year + " has ");
            int count = 0;

            //loop to read process a single year and insert into db
            while (data.hasNext()) {
                count++;
                data.next(); // Skip rank. It is not saved in the table.

                //read boyName
                boyName = data.next();
                //read boyNum
                boyNum = Integer.parseInt(data.next());
                //read girlName
                girlName = data.next();
                //read girlNum
                girlNum = Integer.parseInt(data.next());

                //insert boy variables into prepared statement and execute
                preparedStatement.setInt(1, year);
                preparedStatement.setString(2, boyName);
                preparedStatement.setString(3, "M");
                preparedStatement.setInt(4, boyNum);

                preparedStatement.execute();

                //insert girl variables into prepared statement and execute
                preparedStatement.setInt(1, year);
                preparedStatement.setString(2, girlName);
                preparedStatement.setString(3, "F");
                preparedStatement.setInt(4, girlNum);

                preparedStatement.execute();

            }
            System.out.println("count= " + count);

        }


    }

}

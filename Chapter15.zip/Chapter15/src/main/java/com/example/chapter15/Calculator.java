package com.example.chapter15;
//This program displays a calculator, with action on buttons.

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;

public class Calculator extends Application {
	TextField tfNumber1, tfNumber2, tfResult;
	Button btAdd, btSubtract, btMultiply, btDivide;

  @Override
  // Override the start method in the Application class
  public void start(Stage primaryStage) {
    HBox pane = new HBox();

    //Labels and textfields for the input
    tfNumber1 = new TextField();
    tfNumber2 = new TextField();
    tfResult = new TextField();
    tfResult.setEditable(false);
    tfNumber1.setPrefColumnCount(3);
    tfNumber2.setPrefColumnCount(3);
    tfResult.setPrefColumnCount(3);

    pane.getChildren().addAll(new Label("Number 1: "), tfNumber1,
      new Label("Number 2: "), tfNumber2, new Label("Result: "), tfResult);

    // Create four buttons
    HBox hBox = new HBox(5);
    btAdd = new Button("Add");
    btSubtract = new Button("Subtract");
    btMultiply = new Button("Multiply");
    btDivide = new Button("Divide");
    hBox.setAlignment(Pos.CENTER);
    hBox.getChildren().addAll(btAdd, btSubtract, btMultiply, btDivide);





    BorderPane borderPane = new BorderPane();
    borderPane.setCenter(pane);
    borderPane.setBottom(hBox);
    BorderPane.setAlignment(hBox, Pos.TOP_CENTER);

    // Create a scene and place it in the stage
    Scene scene = new Scene(borderPane, 350, 100);
    primaryStage.setTitle("Calculator"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }//end start


  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }


} //end Calculator
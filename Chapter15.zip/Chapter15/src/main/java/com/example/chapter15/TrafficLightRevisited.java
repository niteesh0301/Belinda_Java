package com.example.chapter15;
//This program displays a stop light with
//red yellow and green lights unlit. A button click
//turns the red light on.

import javafx.application.Application;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;


public class TrafficLightRevisited extends Application {
   //declared circles here, so accessible inside entire class WarmUp_04_22....
	Circle c1;
	Circle c2;
	Circle c3;

	int toggle = 0; //0 is off and 1 on

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {

	  //Populate a pane with a rectangle to hold the three lights
	  //and three circles for the lights

	  //the box to hold the lights
	  Rectangle r1 = new Rectangle(20, 20, 130, 270);
	  r1.setStroke(Color.BLACK);
	  r1.setFill(Color.WHITE);

	  //the lights
	  c1 = new Circle(30);
	  c1.setCenterX(80);
	  c1.setCenterY(70);
	  c1.setStroke(Color.BLACK);


	  c2 = new Circle(30);
	  c2.setCenterX(80);
	  c2.setCenterY(150);
	  c2.setStroke(Color.BLACK);


	  c3 = new Circle(30);
	  c3.setCenterX(80);
	  c3.setCenterY(230);
	  c3.setStroke(Color.BLACK);


	  Pane pane = new Pane();
	  pane.getChildren().addAll(r1,c1, c2, c3);

	 BorderPane bp = new BorderPane();
	 bp.setCenter(pane);

	 //button to turn red light red
	 Button turnRed = new Button("STOP");
	 bp.setBottom(turnRed);

	 //add event handler to turnRed that will turn light red

	 // Create a scene and place a button in the scene
	 Scene scene = new Scene(bp, 200, 340);
	 primaryStage.setTitle("Stop Light"); // Set the stage title
	 primaryStage.setScene(scene); // Place the scene in the stage
	 primaryStage.show(); // Display the stage
  }//end start


  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }

}//end TrafficLightRevisited

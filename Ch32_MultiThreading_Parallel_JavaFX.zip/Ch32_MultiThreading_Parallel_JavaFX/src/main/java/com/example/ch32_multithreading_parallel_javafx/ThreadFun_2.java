//Practice 2 - multiple threads - Take the code from ThreadFun_1 and add:
//  1. Create two threads, each with a different word
//  2. Start these threads after the first thread is started
//  3. Run the program several times, is the output consistent or somewhat different each run?

package com.example.ch32_multithreading_parallel_javafx;

public class ThreadFun_2 {
    public static void main(String[] args) {
        Task2 task1 = new Task2("sunshine", 5);

        Thread thread1 = new Thread(task1);

        thread1.start();
    }
}

class Task2 implements Runnable{
    String word;
    int number;
    public Task2(String word, int number){
        this.word = word;
        this.number = number;
    }

    @Override
    public void run(){
        for (int i = 0; i < number; i++){
            System.out.println(word);
        }
        System.out.println("Task is FINISHED!\n");
    }
}

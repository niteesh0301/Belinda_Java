/* Practice 2 - cached thread pool - Starts with code from ThreadFun_8 and:
    1. use a cached thread pool instead of individual threads.
 */
package com.example.ch32_multithreading_parallel_javafx;

public class ThreadFun_9 {
}

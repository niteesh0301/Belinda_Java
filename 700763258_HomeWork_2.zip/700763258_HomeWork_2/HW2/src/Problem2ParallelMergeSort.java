import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class Problem2ParallelMergeSort {
        public static void main(String[] args) {
            final int SIZE = 7000000;
            Integer[] list1 = new Integer[SIZE];
            Integer[] list2 = new Integer[SIZE];

            for (int i = 0; i < list1.length; i++) {
                list1[i] = list2[i] = (int) (Math.random() * 10000000);
            }
            System.out.println("Printing first 100 of 7000000 elements before sorting ");
            for (int i = 0; i < 100; i++) {
                System.out.print(list1[i] + " ");
            }
            System.out.println();

            long startTime = System.currentTimeMillis();
            parallelMergeSort(list1); // Invoke parallel merge sort
            long endTime = System.currentTimeMillis();

            System.out.println();
            System.out.println("Printing first 100 of 7000000 elements after sorting ");
            for (int i = 0; i < 100; i++) {
                System.out.print(list1[i] + " ");
            }

            System.out.println("\nParallel time with "
                    + Runtime.getRuntime().availableProcessors() +
                    " processors is " + (endTime - startTime) + " milliseconds");

            startTime = System.currentTimeMillis();
            Problem2.mergeSort(list2); // Invoke sequential merge sort
            endTime = System.currentTimeMillis();

            System.out.println();
            System.out.println("Printing first 100 of 7000000 elements after sorting (Sequential)");
            for (int i = 0; i < 100; i++) {
                System.out.print(list2[i] + " ");
            }

            System.out.println("\n\nSequential time is " +
                    (endTime - startTime) + " milliseconds");
            System.out.println("------------------------------------------------------------------");
            // Second Half - Strings
            String[] list3 = new String[SIZE];

            list3 = Problem2RandomString.getRandomStringArray(list3.length);

            System.out.println();
            System.out.println("Printing first 100 of 7000000 strings before sorting ");
            for (int i = 0; i < 100; i++) {
                System.out.print(list3[i] + " ");
            }
            System.out.println();

            startTime = System.currentTimeMillis();
            parallelMergeSort(list3); // Invoke parallel merge sort
            endTime = System.currentTimeMillis();

            System.out.println();
            System.out.println("Printing first 100 of 7000000 strings after sorting ");
            for (int i = 0; i < 100; i++) {
                System.out.print(list3[i] + " ");
            }

            System.out.println("\n\nParallel time for Strings with "
                    + Runtime.getRuntime().availableProcessors() +
                    " processors is " + (endTime - startTime) + " milliseconds");

        }

        public static <E extends Comparable<E>> void parallelMergeSort(E[] list) {
            RecursiveAction mainTask = new SortTask(list);
            ForkJoinPool pool = new ForkJoinPool();
            pool.invoke(mainTask);
        }

        private static class SortTask<E extends Comparable<E>> extends RecursiveAction {
            private final int THRESHOLD = 500;
            private E[] list;

            SortTask(E[] list) {
                this.list = list;
            }

            @Override
            protected void compute() {
                if (list.length < THRESHOLD)
                    java.util.Arrays.sort(list);
                else {
                    // Obtain the first half
                    E[] firstHalf = (E[]) (new Comparable[list.length / 2]);
                    System.arraycopy(list, 0, firstHalf, 0, list.length / 2);

                    // Obtain the second half
                    int secondHalfLength = list.length - list.length / 2;
                    E[] secondHalf = (E[]) (new Comparable[secondHalfLength]);
                    System.arraycopy(list, list.length / 2,
                            secondHalf, 0, secondHalfLength);

                    // Recursively sort the two halves
                    invokeAll(new SortTask(firstHalf),
                            new SortTask(secondHalf));

                    // Merge firstHalf with secondHalf into list
                    Problem2.merge(firstHalf, secondHalf, list);
                }
            }
        }
}

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Problem1 {
        public static SumClass sum = new SumClass(0);

        private static class IncrementSumTask implements Runnable{
            @Override
            public void run() {
                sum.incrementSum(1);
            }
        }

        private static class SumClass {
            private Integer sum;

            SumClass(Integer sum){
                this.sum = sum;
            }

            public Integer getSum(){
                return this.sum;
            }

            public void incrementSum(Integer val){
                sum += val;
            }

            @Override
            public String toString() {
                return "Sum is " + sum;
            }
        }

        public static void main(String[] args) {
            ExecutorService executor = Executors.newFixedThreadPool(1000);

            // Create and launch 100 threads
            for (int i = 0; i < 1000; i++) {
                executor.execute(new IncrementSumTask());
            }

            executor.shutdown();

            // Wait until all tasks are finished
            while (!executor.isTerminated()) {
            }

            System.out.println(sum);
        }
}

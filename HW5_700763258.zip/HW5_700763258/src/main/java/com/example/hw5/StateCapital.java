package com.example.hw5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

public class StateCapital {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/javabook";
    private static final String USER = "root";
    private static final String PASS = "Niteesh@12";

    public static ResultSet getRandomStateCapital() throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            String sql = "SELECT state, capital FROM statecapital ORDER BY RAND() LIMIT 1";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error retrieving random state capital: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return rs;
    }
}